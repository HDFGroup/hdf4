Readme.txt file for the Microsoft-Windows projects.

The project workspace file "Windows.dsw" can be used to build either the static single-threaded libraries, 
or multithreaded DLLs for the HDF libraries.

To build the static single-threaded libraries:
	1)	Select the "hdf files" project.
	2)	Build it in "Win32 Debug", or "Win32 Release".  
		(This depends on weather you want debugging symbols.)

	3)	Select the "mfhdf files" project.
	4)	Build it in the same mode as the "hdf files" project.

To build the multithreaded DLLs:
	1)	Select the "mfhdf_dll files" project.
	2)	Build it in "Win32 Debug", or "Win32 Release".  
		(This depends on weather you want debugging symbols.)
		NOTE:  The "mfhdf_dll files" project has all subordinate projects set as dependancies.

All of the .lib and .dll files will go into the ...\Windows\lib folder.

