ReadMe.txt                                 February 11, 1998

Three files are compressed into DevStu.zip
  MFHDF41r2.dsp      a MicroSoft Developer Studio 97(tm) project file.
  MFHDF41r2.dsw      a MicroSoft Developer Studio 97(tm) workspace file.
  ReadMe.txt         this read-me file.

Goal:
   You should be able to open MFHDF41r2.dsw as a workspace
   in MicroSoft Developer Studio, suitable for developing a  
   project that uses the HDF libraries as static libraries.

Preconditions:
   It is assumed that you have done the following:
	1. Installed MicroSoft Developer Studio 97.
      and Visual C++ 5.0.

	2. Set up the necessary directory structure.

	    c:\							(any drive)
           MyHDFstuff\				(any folder name)


	 3. Run WinZip(tm) on 2 files:
        HDF41r2s(1).zip
		DevStu.zip
  
        c:\							(any drive)
           MyHDFstuff\				(any folder name)
	         dev\...				(created by HDF41r2s(1).zip)
		     DevStudioProject\		(created by DevStu.zip)
			    MFHDF41r2.dsp		(created by DevStu.zip)
			    MFHDF41r2.dsw		(created by DevStu.zip)
                ReadMe.txt			(created by DevStu.zip)
  
	  (The directory dev\ and its sub directories are the only 
	   directories whose names are located in the project files.):

     4. Run WinZip on 
        c:\myHDFstuff\dev\win32mak.zip

     5. Opened c:\myHDFstuff\dev\dev.mak in Developer Studio which converts
	    dev.mak into a Developer Studio project and creates
	    a lot of *.dsp files.

        These 5 project files(referenced in MFHDF41r2.dsw) are 
		needed by MFHDF41r1.dsw:
	       c:\myHDFstuff\dev\jpeg.dsp
	       c:\myHDFstuff\dev\libsrc.dsp
	       c:\myHDFstuff\dev\xdr.dsp
	       c:\myHDFstuff\dev\zlib.dsp
	       c:\myHDFstuff\dev\mfhdf\mfhdf.dsp

Options:
     The files in DevStu.zip must end up in a directory at
     the same level as the dev\ directory installed by
     HDF41r2s(1).zip

     If you must install c and MFHDF41r2.dsp in 
     another directory, relative to dev\ , you will be asked to
	 locate the above 5 project files, when you open the
	 project MFHDF41r1.dsw.
	 
	 If you want to rename MFHDF41R2 (the entire project),
	 you will need to modify two files
	 MFHDF41r1.dsw and MFHDF41r2.dsp as text
	 (contrary to the explicit warnings in the files).

	 You can also modify MFHDF41r1.dsw and MFHDF41r2.dsp
	 as text, to allow these project files to be installed
	 in another directory.

	 

Building the MFHDF41r1.dsw/MFHDF41r2.dsp project:

  Having set up the directories and modified the two files as
  necessary, it should be possible to open the project in
  Developer Studio and build it.

  The 5 sub projects are all build as static libraries.
  You can then add your own source files that actually use
  the HDF libraries.

  Settings... details:
  If you create your own project, the necessary settings can be
  read from the MFHDF41r2.dsp file(as text), or from the
  Project Settings in Developer Studio.

    Project
	  Settings
	     C/C++
		   Category
		     PreProcessor

			 Code Generation
			    Use run-time Library
				   These are all set to use Multi-Threaded DLL.
				   or Multi-Thread DLL debug.

---------------------------------------------------------------
Jim Bates   jimbo@fortner.com
Fortner Software LLC
100 Carpenter Drive Suite 203
Sterling VA 20164
---------------------------------------------------------------
