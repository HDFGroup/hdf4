DevStuReadMe.txt                                 April 17, 1998

Eight files are compressed into DevStu.zip

  Three files which will not conflict with any other files:
    MFHDF41r2.dsp      a MicroSoft Developer Studio 97(tm) project file.
    MFHDF41r2.dsw      a MicroSoft Developer Studio 97(tm) workspace file.
    DevStuReadMe.txt   this read-me file.

  Five files may have already been installed by decompressing win32nofmak.zip
    (WIN32, NO Fortran, Make)
    .\hdf\hdf.dsp
    .\mfhdf\mfhdf.dsp
    .\jpeg.dsp
    .\xdr.dsp
    .\zlib.dsp

Goal:
   You should be able to open MFHDF41r2.dsw in MicroSoft Developer
   Studio as a workspace suitable for developing a project that 
   uses the HDF libraries as static libraries.

Preconditions:
   It is assumed that you have done the following:
      1. Installed MicroSoft Developer Studio 97.
           and Visual C++ 5.0.

      2. Set up a directory structure.

	    c:\					(any drive)
           MyHDFstuff\				(any folder name)

      3. Run WinZip(tm) on 2 files:
         Everyone needs this:
         HDF41r2s(1).zip                 (the entire source tree)

            Replace the contents of two text files with platform 
            specific file contents.
            Copy hdf\jpeg\config\jwin32.h to hdf\jpeg\jconfig.h
            Copy mfhdf\libsrc\win32cdf.h to mfhdf\libsrc\netcdf.h

         Use one of these options:
 
            (optional step 3 using DevStu.zip) 
 	       DevStu.zip                      (an optional Dev Studio project file,
                                                intended as a minimal starter project.)

               Run WinZip on 
               c:\myHDFstuff\dev\DevStu.zip
               This archive contains a Developer Studio project "MFHDF41r2"
               which, when expanded and built, will provide:
                  hdf library

                  c:\					(any drive)
                    MyHDFstuff\			        (any folder)
                       dev\			        (created by HDF41r2s(1).zip)
 	               dev\MFHDF41r2.dsp		(created by DevStu.zip)
      	               dev\MFHDF41r2.dsw		(created by DevStu.zip)
                       dev\DevStuReadMe.txt	        (created by DevStu.zip)
                       dev\hdf\hdf.dsp     	        (created by DevStu.zip)
                       dev\mfhdf\mfhdf.dsp 	        (created by DevStu.zip)
                       dev\jpeg.dsp        	        (created by DevStu.zip)
                       dev\xdr.dsp         	        (created by DevStu.zip)
                       dev\zlib.dsp        	        (created by DevStu.zip)

               This project is intended for use as a starter project.
               Open  c:\myHDFstuff\dev\MFHDF41r2.dsw in Developer Studio
               and Build. You can then add your own source files to this
               project.

            (optional step 3 using win32nof.zip) 
               win32nof.zip                    (an optional Dev Studio project file which
                                                contains test utilities and several
                                                hdf utilities).
               Run WinZip on 
               c:\myHDFstuff\dev\win32nof.zip
               This archive contains a Developer Studio project "dev" and two batch
               files which, when expanded and built, will provide:
                  hdf library
                  hdf utitities
                  test programs
                  test batch files.

               This project is not intended for use as a starter project.
               This project is explained in the text file
               "Install_winNT_FPS.txt" on the ftp server that contained
               HDF41r2s(1).zip.

               Open  c:\myHDFstuff\dev\dev.mak in Developer Studio which converts
	       dev.mak into a Developer Studio project and creates
	       40 *.dsp files. 

 
Project name and location:
         The files in DevStu.zip must end up in the dev\ directory
         installed by HDF41r2s(1).zip

         If you must install MFHDF41r2.dsw and MFHDF41r2.dsp in 
         another directory, relative to dev\ , you will be asked to
	 locate the above 5 sub-project files, when you open the
	 project MFHDF41r1.dsw.
	 
	 If you want to rename MFHDF41R2 (the entire project),
	 you will need to modify two files
	 MFHDF41r1.dsw and MFHDF41r2.dsp as text
	 (contrary to the explicit warnings in the files).

	 You can also modify MFHDF41r1.dsw and MFHDF41r2.dsp
	 as text, to allow these 2 files to be installed
	 in another directory.

Building the MFHDF41r1.dsw/MFHDF41r2.dsp project:

  Having set up the directories and modified the two project files 
  (if necessary), it should be possible to open the project in
  Developer Studio and build it.

  The 5 sub projects are all built as static libraries.
  You can then add your own source files that actually use
  the HDF libraries.

  Settings... details:
  If you create your own project, the necessary settings can be
  read from the MFHDF41r2.dsp file(as text), or from the
  Project Settings in the Developer Studio project settings dialog.

    Project
	  Settings
	      C/C++
		  Category
		     PreProcessor
			 Code Generation
			    Use run-time Library
				   These are all set to use Single-Threaded.
				   or Single-Threaded debug.


    
---------------------------------------------------------------
Jim Bates   jimbo@fortner.com
Fortner Software LLC
100 Carpenter Drive Suite 203
Sterling VA 20164
---------------------------------------------------------------
